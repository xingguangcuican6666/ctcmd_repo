# -*- coding: utf-8 -*-
"""
convert_to_gbk.py

批量将“当前终端工作目录”中的文本文件转码为 GBK（Windows cp936）。
- 默认仅处理常见文本扩展名；可通过 --all 或 --include/--exclude 调整。
- 支持递归子目录、创建备份、大小限制、干跑。
- 自动跳过包含空字节的二进制文件与超过大小限制的文件。

使用示例（PowerShell）：
1) 在你需要转换的目录中执行（非递归）：
   py "<repo>/tools/convert_to_gbk.py"

2) 递归转换并为每个文件生成 .bak 备份：
   py "<repo>/tools/convert_to_gbk.py" -r -b

3) 指定包含/排除规则（逗号分隔或多次指定）：
   py "<repo>/tools/convert_to_gbk.py" -r --include "*.txt,*.md" --exclude "*.bin,*.png"

4) 遇到无法用 GBK 表示的字符时采用替换策略而不是报错：
   py "<repo>/tools/convert_to_gbk.py" -r --errors replace

注意：脚本作用于“你运行命令时所在的目录”（CWD），与脚本所在位置无关。
"""

from __future__ import annotations

import argparse
import fnmatch
import os
from pathlib import Path
import shutil
import sys
from typing import Iterable, List, Optional, Sequence, Tuple

# 常见文本扩展名（小写匹配）
DEFAULT_INCLUDE_PATTERNS: List[str] = [
    "*.txt", "*.md", "*.csv", "*.log", "*.json", "*.xml", "*.html", "*.htm",
    "*.ini", "*.cfg", "*.yml", "*.yaml", "*.toml", "*.properties",
    "*.bat", "*.ps1", "*.sh",
    "*.py", "*.js", "*.ts", "*.css",
    "*.java", "*.kt", "*.kts",
    "*.c", "*.cpp", "*.h", "*.hpp",
    "*.cs", "*.go", "*.rs", "*.rb", "*.php", "*.pl",
    "*.sql", "*.swift", "*.lua", "*.conf", "*.gradle"
]

# 递归时跳过的目录名（大小写不敏感，完整目录名匹配）
SKIP_DIRS = {
    ".git", ".svn", ".hg", ".idea", ".vscode", ".vs",
    "node_modules", "dist", "build", "target", "out",
    "venv", ".venv", "env", ".env", "__pycache__"
}

# 尝试的源编码优先级（不依赖第三方库）
CANDIDATE_ENCODINGS: Tuple[str, ...] = (
    "utf-8-sig", "utf-8",
    "utf-16", "utf-16le", "utf-16be",
    "utf-32", "utf-32le", "utf-32be",
    "gb18030", "big5", "shift_jis",
    "iso-8859-1",
)


def parse_multi_patterns(values: Optional[Sequence[str]]) -> List[str]:
    patterns: List[str] = []
    if not values:
        return patterns
    for v in values:
        if not v:
            continue
        parts = [p.strip() for p in v.split(',') if p.strip()]
        patterns.extend(parts)
    return patterns


def is_binary_file(path: Path, sample_size: int = 4096) -> bool:
    """通过空字节快速判断二进制文件。"""
    try:
        with path.open('rb') as f:
            chunk = f.read(sample_size)
            if b"\x00" in chunk:
                return True
    except Exception:
        # 无法读取时，保守跳过
        return True
    return False


def match_any(name: str, patterns: Sequence[str]) -> bool:
    name_lower = name.lower()
    for pat in patterns:
        if fnmatch.fnmatch(name_lower, pat.lower()):
            return True
    return False


def try_decode_all(data: bytes, preferred: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """尝试用多种编码完整解码，返回 (文本, 使用的编码)。"""
    if preferred:
        try:
            return data.decode(preferred), preferred
        except Exception:
            pass
    for enc in CANDIDATE_ENCODINGS:
        try:
            return data.decode(enc), enc
        except Exception:
            continue
    return None, None


def iter_files(base: Path, recursive: bool) -> Iterable[Path]:
    if not recursive:
        for p in base.iterdir():
            if p.is_file():
                yield p
        return
    # 递归遍历并剪枝跳过目录
    for root, dirs, files in os.walk(base):
        # 剪枝: 跳过常见大/工具/版本控制目录
        dirs[:] = [d for d in dirs if d.lower() not in {s.lower() for s in SKIP_DIRS}]
        root_path = Path(root)
        for name in files:
            p = root_path / name
            if p.is_file():
                yield p


def should_process_file(path: Path, *,
                        include: Sequence[str],
                        exclude: Sequence[str],
                        all_files: bool) -> bool:
    name = path.name
    if not all_files:
        if include and not match_any(name, include):
            return False
    if exclude and match_any(name, exclude):
        return False
    return True


def make_backup(src: Path, *, backup_dir: Optional[Path]) -> Path:
    if backup_dir:
        backup_dir.mkdir(parents=True, exist_ok=True)
        dst = backup_dir / src.name
    else:
        # 在同目录创建 .bak 文件（如 a.txt -> a.txt.bak）
        dst = src.with_suffix(src.suffix + ".bak")
    shutil.copy2(src, dst)
    return dst


def convert_file_to_gbk(path: Path, *,
                         from_encoding: Optional[str],
                         write_errors: str,
                         dry_run: bool,
                         do_backup: bool,
                         backup_dir: Optional[Path]) -> Tuple[bool, str, Optional[str]]:
    """将单个文件转为 GBK。返回 (是否修改, 消息, 源编码或错误)。"""
    try:
        data = path.read_bytes()
    except Exception as e:
        return False, f"读取失败: {e}", None

    text, used_enc = try_decode_all(data, preferred=from_encoding)
    if text is None:
        return False, "无法识别或解码该文件编码", None

    # 先在内存中验证是否可无损/按策略编码为 GBK
    try:
        _ = text.encode('gbk', errors=write_errors)
    except Exception as e:
        return False, f"写入前编码检查失败: {e}", used_enc

    if dry_run:
        return True, "干跑：将转换为 GBK（未写入）", used_enc

    try:
        if do_backup:
            make_backup(path, backup_dir=backup_dir)
        # 使用 newline='' 原样保留换行符风格
        with path.open('w', encoding='gbk', errors=write_errors, newline='') as f:
            f.write(text)
        return True, "已转换为 GBK", used_enc
    except Exception as e:
        return False, f"写入失败: {e}", used_enc


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="将当前终端工作目录中的文本文件批量转为 GBK (cp936)")
    parser.add_argument('-r', '--recursive', action='store_true',
                        help='递归处理子目录（会自动跳过常见构建/版本控制目录）')
    parser.add_argument('--all', action='store_true',
                        help='不按扩展名筛选，尽量处理所有看起来像文本的文件（仍会跳过含空字节的二进制文件）')
    parser.add_argument('-i', '--include', action='append', default=[],
                        help='仅处理匹配的文件名通配（可多次指定或用逗号分隔），默认内置常见文本扩展名')
    parser.add_argument('-e', '--exclude', action='append', default=[],
                        help='排除匹配的文件名通配（可多次指定或用逗号分隔）')
    parser.add_argument('--max-bytes', type=int, default=5 * 1024 * 1024,
                        help='仅处理不超过该大小的文件（字节），默认 5MB；设为 0 表示不限制')
    parser.add_argument('-b', '--backup', action='store_true',
                        help='转换前创建备份（同目录 .bak 或 --backup-dir 指定目录）')
    parser.add_argument('--backup-dir', type=str, default=None,
                        help='将备份写入该目录（会自动创建），而不是同目录 .bak 文件')
    parser.add_argument('--from-enc', dest='from_enc', type=str, default=None,
                        help='指定源编码；未指定时将自动尝试一组常见编码')
    parser.add_argument('--errors', choices=['strict', 'ignore', 'replace'], default='strict',
                        help='写入 GBK 时遇到不可表示字符的处理策略，默认 strict')
    parser.add_argument('-n', '--dry-run', action='store_true',
                        help='仅显示将要做的更改，不实际写入')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='输出更详细的处理信息')

    args = parser.parse_args(argv)

    cwd = Path.cwd()
    include = parse_multi_patterns(args.include) or DEFAULT_INCLUDE_PATTERNS
    exclude = parse_multi_patterns(args.exclude)
    backup_dir = Path(args.backup_dir) if args.backup_dir else None

    total = 0
    converted = 0
    skipped = 0
    failed = 0

    for p in iter_files(cwd, recursive=args.recursive):
        if args.max_bytes and p.stat().st_size > args.max_bytes:
            skipped += 1
            if args.verbose:
                print(f"[SKIP 大小] {p} > {args.max_bytes} bytes")
            continue
        if is_binary_file(p):
            skipped += 1
            if args.verbose:
                print(f"[SKIP 二进制] {p}")
            continue
        if not should_process_file(p, include=include, exclude=exclude, all_files=args.all):
            continue

        total += 1
        changed, message, used_enc = convert_file_to_gbk(
            p,
            from_encoding=args.from_enc,
            write_errors=args.errors,
            dry_run=args.dry_run,
            do_backup=args.backup,
            backup_dir=backup_dir,
        )
        if changed:
            converted += 1
            enc_info = f"（源编码: {used_enc}）" if used_enc else ""
            print(f"[OK] {p} -> GBK {enc_info} {('(dry-run)' if args.dry_run else '')}")
        else:
            if message.startswith("读取失败") or message.startswith("写入失败") or message.startswith("无法") or message.startswith("写入前编码检查失败"):
                failed += 1
            else:
                skipped += 1
            more = f"（源编码: {used_enc}）" if used_enc else ""
            print(f"[SKIP/FAIL] {p} - {message} {more}")

    print("\n—— 统计 ——")
    print(f"候选: {total}")
    print(f"已转换: {converted}")
    print(f"跳过: {skipped}")
    print(f"失败: {failed}")

    # 只要存在失败则返回非零，便于在 CI/脚本中察觉问题
    return 0 if failed == 0 else 1


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("已取消")
        sys.exit(130)

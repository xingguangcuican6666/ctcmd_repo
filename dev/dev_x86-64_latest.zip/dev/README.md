# Welcome

### 如何上传项目
Powershell 打开 tools , 然后执行upload.bat即可
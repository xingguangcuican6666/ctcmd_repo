@echo off
setlocal enabledelayedexpansion
set "HOME=%~dp0\.."
set "WORKSPACE=%~dp0"
set "work=%cd%"
call "%HOME%\libctcmd\config.bat"
if "%1" == "" (
    echo Usage: dev.init [^<module_name^>]
    echo.
    echo Example: dev.init my_module
    goto :eof
)
if not exist "%HOME%\libctcmd\config.bat" (
    echo Error: ��û��������Ҫ��¡��ģ��ֿ⣬���ȴ��� config.bat �ļ���
    notepad "%HOME%\libctcmd\config.bat"
    goto :eof
)
xcopy /E /Y "%WORKSPACE%tools\*" "%work%\tools\"
echo set name=%1>"%work%\tools\config.bat"
echo set ctcmd_repo=%repo%>>"%work%\tools\config.bat"
echo set ctcmd_upload=%uploader%>>"%work%\tools\config.bat"
:eof
endlocal
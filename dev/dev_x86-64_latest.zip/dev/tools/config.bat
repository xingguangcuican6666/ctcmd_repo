set name=dev
set ctcmd_upload="C:\Program Files\ctcmd_uploader\ctcmd_upload.bat"
@echo off
setlocal enabledelayedexpansion
call config.bat
set "H_PATH=%~dp0..\"
cd /d "%H_PATH%.."
set "T_P=%H_PATH%tools\"
for /f "delims=" %%v in (.\%name%\version.txt) do set "version=%%v"
for /f "tokens=1-3 delims=." %%a in ("!version!") do (
    set "major=%%a"
    set "minor=%%b"
    set "patch=%%c"
)
set /a patch+=1
set "newversion=!major!.!minor!.!patch!"
del /s /q ".\%name%.zip"
"%T_P%\7z.exe" a -tzip -y ".\%name%.zip" ".\%name%"
echo !newversion! > .\%name%\version.txt
%ctcmd_upload% .\%name%.zip %name% x86-64 !version!
